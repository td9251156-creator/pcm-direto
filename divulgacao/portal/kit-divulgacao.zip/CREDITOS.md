# Créditos

O PCM Direto é feito por quem trabalha com manutenção, para quem trabalha com manutenção.
Toda contribuição aceita entra nesta página, programando ou não.

## Autor e mantenedor

- **Thiago Oliveira Lima**: ideia, regras de PCM, modelos da Biblioteca PCM v2 (PCM-MAN) e revisão de todo o conteúdo.
  [linkedin.com/in/thiagooliveiralima94](https://linkedin.com/in/thiagooliveiralima94)

## Quem ajudou

Ainda não há contribuições registradas. A primeira pode ser a sua: veja
[Como contribuir](CONTRIBUTING.md#sem-programar).

| Nome (ou apelido) | Como ajudou | Quando |
|---|---|---|
| | | |

Formas que contam como contribuição:

- **Teste de uso:** testou o app e mandou o formulário ou um e-mail com o que achou.
- **Revisão de tarefa:** conferiu tarefas da biblioteca com o manual do fabricante.
- **Sugestão de tarefa ou máquina:** sugeriu algo que entrou na biblioteca.
- **Artigo:** sugeriu ou revisou um guia da Central de apoio.
- **Modelo:** publicou um modelo aprovado na comunidade do app.
- **Erro relatado:** relatou um problema que foi corrigido.
- **Código:** teve um *pull request* aceito.

O nome só entra com autorização de quem contribuiu. Quem preferir pode usar apelido ou ficar anônimo.

## Ferramentas de terceiros

O PCM Direto usa estas bibliotecas abertas, cada uma com a sua licença:

| Ferramenta | Para que serve | Licença |
|---|---|---|
| [Vite](https://vite.dev/) | Montar a versão final do app | MIT |
| [ExcelJS](https://github.com/exceljs/exceljs) | Ler as planilhas da Biblioteca PCM v2 e gerar a planilha do planejamento | MIT |
| [docx](https://github.com/dolanmiu/docx) | Preencher os manuais em Word | MIT |
| [JSZip](https://stuk.github.io/jszip/) | Ler e montar arquivos compactados | MIT ou GPL-3.0 (usada sob MIT) |
| [supabase-js](https://github.com/supabase/supabase-js) | Catálogo online da comunidade | MIT |
| [Vitest](https://vitest.dev/) e [ESLint](https://eslint.org/) | Testes e conferência do código | MIT |
| [Playwright](https://playwright.dev/), [PGlite](https://pglite.dev/) e [pdf-lib](https://pdf-lib.js.org/) | Testes no navegador, no banco e nos PDFs | Apache-2.0, Apache-2.0 e MIT |
| [ReportLab](https://www.reportlab.com/opensource/) | Gerar as fichas PDF da biblioteca | BSD |
| [Archivo](https://github.com/Omnibus-Type/Archivo) e [IBM Plex Mono](https://github.com/IBM/plex) | Fontes locais da interface e documentos | SIL OFL 1.1; textos preservados em `public/fontes/archivo-OFL.txt` e `ibmplexmono-OFL.txt` |
| [DejaVu Sans](https://dejavu-fonts.github.io/) | Referência tipográfica histórica do projeto | Licença livre DejaVu |

Parte do código foi escrita com ajuda de IA e revisada pelo autor.

As atribuições acima e os arquivos originais da marca são preservados; esta atualização não substitui licenças de terceiros pela MIT. Ferramentas de IA não são exigidas de contribuidores. Uso relevante deve ser informado na entrega, conforme [CONTRIBUTING](CONTRIBUTING.md).
