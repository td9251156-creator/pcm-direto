/* @ds-bundle: {"format":4,"namespace":"PCMDiretoDesignSystem_280618","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"FormTable","sourcePath":"components/data/FormTable.jsx"},{"name":"StatusTag","sourcePath":"components/data/StatusTag.jsx"},{"name":"DocHeader","sourcePath":"components/document/DocHeader.jsx"},{"name":"NoteBox","sourcePath":"components/document/NoteBox.jsx"},{"name":"SectionHeading","sourcePath":"components/document/SectionHeading.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"433ec0e6ca56","components/data/DataTable.jsx":"9943824d2a89","components/data/FormTable.jsx":"7f4d10ee004e","components/data/StatusTag.jsx":"87c3bdb397ab","components/document/DocHeader.jsx":"5389d1d2f432","components/document/NoteBox.jsx":"97e4c2dac7e2","components/document/SectionHeading.jsx":"55207ff21986"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PCMDiretoDesignSystem_280618 = window.PCMDiretoDesignSystem_280618 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
const MAP = {
  vertical: 'vertical',
  horizontal: 'horizontal',
  slogan: 'horizontal-slogan',
  icon: 'icone-app'
};
function Logo({
  variant = 'horizontal',
  tone = 'cor',
  height = 40,
  base = '',
  style
}) {
  const t = variant === 'icon' ? tone === 'negativo' ? '_negativo' : '' : '_' + tone;
  return /*#__PURE__*/React.createElement("img", {
    alt: "PCM Direto",
    src: base + 'assets/logo/PCM-Direto_' + MAP[variant] + t + '.svg',
    style: {
      height,
      display: 'block',
      ...style
    }
  });
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function DataTable({
  columns = [],
  rows = [],
  caption,
  mono = []
}) {
  const th = {
    background: 'var(--azul-pcm)',
    color: '#fff',
    fontWeight: 700,
    fontSize: 12,
    textAlign: 'left',
    padding: '8px 10px'
  };
  const td = {
    borderBottom: '1px solid var(--linha)',
    padding: '7px 10px',
    fontSize: 13,
    verticalAlign: 'top'
  };
  return /*#__PURE__*/React.createElement("table", {
    style: {
      borderCollapse: 'collapse',
      width: '100%',
      fontFamily: 'var(--font-sans)',
      color: 'var(--tinta)'
    }
  }, caption && /*#__PURE__*/React.createElement("caption", {
    style: {
      captionSide: 'bottom',
      textAlign: 'left',
      fontSize: 11,
      color: 'var(--cinza-texto)',
      paddingTop: 6
    }
  }, caption), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c,
    style: th
  }, c)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      background: i % 2 ? 'var(--superficie)' : '#fff'
    }
  }, r.map((v, j) => /*#__PURE__*/React.createElement("td", {
    key: j,
    style: {
      ...td,
      ...(mono.includes(j) ? {
        fontFamily: 'var(--font-mono)',
        fontSize: 12
      } : {})
    }
  }, v))))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/FormTable.jsx
try { (() => {
function FormTable({
  rows = []
}) {
  const cell = {
    border: '1px solid var(--linha)',
    padding: '7px 10px',
    fontSize: 13
  };
  return /*#__PURE__*/React.createElement("table", {
    style: {
      borderCollapse: 'collapse',
      width: '100%',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['Campo', 'Valor', 'Orientação'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      ...cell,
      background: 'var(--azul-pcm)',
      color: '#fff',
      textAlign: 'left',
      fontSize: 12
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      ...cell,
      fontWeight: 600
    }
  }, r.field), /*#__PURE__*/React.createElement("td", {
    style: {
      ...cell,
      background: r.auto ? 'var(--cinza-auto)' : 'var(--azul-claro)',
      color: r.auto ? 'var(--cinza-auto-texto)' : 'var(--tinta)'
    }
  }, r.value), /*#__PURE__*/React.createElement("td", {
    style: {
      ...cell,
      color: 'var(--cinza-texto)',
      fontSize: 12
    }
  }, r.hint)))));
}
Object.assign(__ds_scope, { FormTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/FormTable.jsx", error: String((e && e.message) || e) }); }

// components/data/StatusTag.jsx
try { (() => {
const T = {
  ok: ['--ok', '--ok-bg'],
  pendente: ['--pendente', '--pendente-bg'],
  erro: ['--erro', '--erro-bg'],
  inativo: ['--cinza-auto-texto', '--cinza-auto'],
  ativo: ['--azul-pcm', '--azul-claro']
};
function StatusTag({
  status = 'ok',
  children
}) {
  const [c, b] = T[status] || T.ok;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      padding: '2px 8px',
      borderRadius: 2,
      background: 'var(' + b + ')',
      color: 'var(' + c + ')',
      font: '600 11px var(--font-mono)'
    }
  }, children);
}
Object.assign(__ds_scope, { StatusTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatusTag.jsx", error: String((e && e.message) || e) }); }

// components/document/DocHeader.jsx
try { (() => {
function DocHeader({
  code = 'PCMD-00',
  title,
  rev = '00',
  date,
  author,
  approver,
  logo
}) {
  const m = {
    font: '11px var(--font-mono)',
    color: 'var(--cinza-texto)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderBottom: '4px solid var(--laranja-sinal)',
      paddingBottom: 12,
      display: 'flex',
      gap: 24,
      alignItems: 'flex-end',
      fontFamily: 'var(--font-sans)'
    }
  }, logo, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: m
  }, code), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 800,
      color: 'var(--azul-pcm)',
      lineHeight: 1.15
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      ...m,
      textAlign: 'right',
      lineHeight: 1.6
    }
  }, "Rev. ", rev, " \xB7 ", date, /*#__PURE__*/React.createElement("br", null), "Elaborado: ", author, /*#__PURE__*/React.createElement("br", null), "Aprovado: ", approver));
}
Object.assign(__ds_scope, { DocHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/document/DocHeader.jsx", error: String((e && e.message) || e) }); }

// components/document/NoteBox.jsx
try { (() => {
function NoteBox({
  label = 'NOTA',
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      background: 'var(--superficie)',
      borderTop: '2px solid var(--laranja-sinal)',
      padding: '10px 14px',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--tinta)'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--laranja-texto)',
      letterSpacing: '.06em'
    }
  }, label), /*#__PURE__*/React.createElement("span", null, children));
}
Object.assign(__ds_scope, { NoteBox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/document/NoteBox.jsx", error: String((e && e.message) || e) }); }

// components/document/SectionHeading.jsx
try { (() => {
function SectionHeading({
  number,
  children,
  level = 1
}) {
  const s = level === 1 ? {
    fontSize: 18,
    fontWeight: 700,
    color: 'var(--azul-pcm)',
    textTransform: 'uppercase',
    borderBottom: '1px solid var(--linha)',
    paddingBottom: 6,
    margin: '24px 0 10px'
  } : {
    fontSize: 15,
    fontWeight: 700,
    color: 'var(--tinta)',
    margin: '16px 0 6px'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      ...s
    }
  }, number && /*#__PURE__*/React.createElement("span", null, number, level === 1 ? '.' : '', "\xA0\xA0"), children);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/document/SectionHeading.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.FormTable = __ds_scope.FormTable;

__ds_ns.StatusTag = __ds_scope.StatusTag;

__ds_ns.DocHeader = __ds_scope.DocHeader;

__ds_ns.NoteBox = __ds_scope.NoteBox;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

})();
