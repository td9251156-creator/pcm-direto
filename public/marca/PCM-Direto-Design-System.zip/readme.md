# PCM Direto — Design System

**PCM Direto** — "Manutenção planejada. Direto ao ponto." A Brazilian maintenance planning & control (PCM — Planejamento e Controle de Manutenção) brand. Deliverables are procedure documents (Word), registers/forms (Excel) and a web presence (favicon/app icon set exists). Language: Portuguese (pt-BR).

**Source:** local folder `PCM-Direto-Marca/` (brand kit v02, Oct 2026): `LEIA-ME.txt` (rules + palette), `SVG/`, `PNG/`, `Favicon/`, `Word/PCMD-Modelo-Padrao.docx`, `Excel/PCMD-Modelo-Padrao.xlsx`. No app/website code was provided.

## Index
- `styles.css` → `tokens/` (fonts, colors, typography, spacing)
- `guidelines/` — foundation cards
- `components/brand` Logo · `components/document` DocHeader, SectionHeading, NoteBox · `components/data` DataTable, FormTable, StatusTag
- `ui_kits/documento` (Word procedure) · `ui_kits/planilha` (Excel table + form)
- `assets/logo`, `assets/favicon`, `assets/templates` (original .docx/.xlsx)
- `SKILL.md`, `thumbnail.html`

## Components
- Logo — official SVG lockups (vertical, horizontal, slogan, icon; tones cor/negativo/azul/preto/branco)
- DocHeader — code, title, Rev./date, Elaborado/Aprovado, orange bar
- SectionHeading — numbered "1.  OBJETIVO" / "5.1  Subtítulo"
- NoteBox — "NOTA" callout
- DataTable — azul header table
- FormTable — Campo/Valor/Orientação with input (azul-claro) vs automatic (cinza) cells
- StatusTag — OK / Ativo / Inativo / Pendente / ERRO

Inventory derived from the Word/Excel templates (the only "UI" sources). No buttons/inputs etc. were defined, so none were invented.

## Content fundamentals
- Portuguese, impersonal and imperative: "Preencha a data.", "Corrija o ID na tabela.", "Nada a fazer."
- Short, functional sentences; the slogan pattern is two terse statements ending in periods.
- Section titles UPPERCASE and numbered (1. OBJETIVO … 7. HISTÓRICO DE REVISÕES). Body sentence case.
- Status messages = state + reason: "Pendente: falta a data", "ERRO: ID repetido". ERRO/NOTA in caps.
- Never presume: empty values read "A definir". Placeholders are generic ("Pessoa A", "Indústria Exemplo", "(exemplo)").
- Codes in mono: document codes `PCMD-03`, equipment TAGs `UTL-CMP-001`, IDs `eq-001`, dates `25/10/2026`.
- No emoji. No exclamation marks. No "você"-heavy marketing voice.

## Visual foundations
- **Colors:** Azul PCM #0B2A5B dominant; Laranja sinal #E2701F only as a signal (the bar under PCM, accent rules). Orange text on white uses #B85600. White text on orange is forbidden (3.2:1). Neutrals: Tinta #0E1726, Cinza texto #4A5668, Linha #DDE3EA, Superfície #F4F6F9. Status colors (OK/Pendente/ERRO) are additions inferred from the templates' messages — confirm.
- **Type:** Archivo — 900 for "PCM", 600 for "DIRETO", 500/700 slogan, 400–800 text. IBM Plex Mono for TAGs, codes, data.
- **Motif:** the horizontal orange bar — under the wordmark, beneath document headers, on active tabs.
- **Backgrounds:** flat white or flat Azul PCM. No gradients, imagery, textures or illustrations in the kit.
- **Corners:** square (0–2px). App icon only: radius 22%.
- **Borders/cards:** 1px Linha rules; tables with solid azul header and zebra superfície rows. Shadows almost absent (only a faint page shadow on a document preview).
- **Spacing:** 4px-based scale; generous document margins.
- **Motion/hover:** none defined. Suggest none/instant; hover = Laranja texto for links.
- **Transparency/blur:** not used.
- **Logo rules:** clearance = half of PCM height; min height vertical 36px/10mm, horizontal 22px/6mm; no distortion, rotation, recolor; slogan only with horizontal lockup.

## Iconography
No icon set in the source. Brand marks only (logo SVGs, app icon, favicons — copied to `assets/`). No emoji or unicode icons. If icons are needed, use a thin geometric set (e.g. Lucide via CDN) — **substitution, not brand-provided**.

## Fonts
Archivo + IBM Plex Mono loaded from Google Fonts (the kit specifies them as Google Fonts; no binaries shipped). The .docx falls back to Arial.
