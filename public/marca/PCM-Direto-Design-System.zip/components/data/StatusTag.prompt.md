Situação/Conferência label for table cells. Message text explains the fix (e.g. "ERRO: falta a TAG").
```jsx
<StatusTag status="erro">ERRO: falta a TAG</StatusTag>
```