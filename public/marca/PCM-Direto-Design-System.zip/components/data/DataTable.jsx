import React from 'react';
export function DataTable({columns=[],rows=[],caption,mono=[]}){
  const th={background:'var(--azul-pcm)',color:'#fff',fontWeight:700,fontSize:12,textAlign:'left',padding:'8px 10px'};
  const td={borderBottom:'1px solid var(--linha)',padding:'7px 10px',fontSize:13,verticalAlign:'top'};
  return <table style={{borderCollapse:'collapse',width:'100%',fontFamily:'var(--font-sans)',color:'var(--tinta)'}}>
    {caption&&<caption style={{captionSide:'bottom',textAlign:'left',fontSize:11,color:'var(--cinza-texto)',paddingTop:6}}>{caption}</caption>}
    <thead><tr>{columns.map(c=><th key={c} style={th}>{c}</th>)}</tr></thead>
    <tbody>{rows.map((r,i)=><tr key={i} style={{background:i%2?'var(--superficie)':'#fff'}}>{r.map((v,j)=><td key={j} style={{...td,...(mono.includes(j)?{fontFamily:'var(--font-mono)',fontSize:12}:{})}}>{v}</td>)}</tr>)}</tbody>
  </table>;
}