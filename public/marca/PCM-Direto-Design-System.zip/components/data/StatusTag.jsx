import React from 'react';
const T={ok:['--ok','--ok-bg'],pendente:['--pendente','--pendente-bg'],erro:['--erro','--erro-bg'],inativo:['--cinza-auto-texto','--cinza-auto'],ativo:['--azul-pcm','--azul-claro']};
export function StatusTag({status='ok',children}){
  const [c,b]=T[status]||T.ok;
  return <span style={{display:'inline-block',padding:'2px 8px',borderRadius:2,background:'var('+b+')',color:'var('+c+')',font:'600 11px var(--font-mono)'}}>{children}</span>;
}