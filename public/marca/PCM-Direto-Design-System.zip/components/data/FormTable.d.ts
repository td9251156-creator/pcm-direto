export interface FormRow{field:string;value:React.ReactNode;hint?:string;/** automatic/calculated cell: grey */auto?:boolean}
export interface FormTableProps{rows:FormRow[]}
export declare function FormTable(p:FormTableProps):JSX.Element;