import React from 'react';
export function FormTable({rows=[]}){
  const cell={border:'1px solid var(--linha)',padding:'7px 10px',fontSize:13};
  return <table style={{borderCollapse:'collapse',width:'100%',fontFamily:'var(--font-sans)'}}>
    <thead><tr>{['Campo','Valor','Orientação'].map(h=><th key={h} style={{...cell,background:'var(--azul-pcm)',color:'#fff',textAlign:'left',fontSize:12}}>{h}</th>)}</tr></thead>
    <tbody>{rows.map((r,i)=><tr key={i}><td style={{...cell,fontWeight:600}}>{r.field}</td>
      <td style={{...cell,background:r.auto?'var(--cinza-auto)':'var(--azul-claro)',color:r.auto?'var(--cinza-auto-texto)':'var(--tinta)'}}>{r.value}</td>
      <td style={{...cell,color:'var(--cinza-texto)',fontSize:12}}>{r.hint}</td></tr>)}</tbody></table>;
}