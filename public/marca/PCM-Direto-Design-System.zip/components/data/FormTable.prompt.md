Spreadsheet-style form: input cells light blue, automatic cells grey.
```jsx
<FormTable rows={[{field:'Responsável',value:'Pessoa A'},{field:'Meta (%)',value:'A definir',auto:true}]}/>
```