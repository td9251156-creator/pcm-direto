Branded table: azul header row, zebra superfície rows, 1px linha rules.
```jsx
<DataTable columns={['ID','TAG','Descrição']} mono={[0,1]} rows={[['eq-001','UTL-CMP-001','Compressor de ar']]}/>
```