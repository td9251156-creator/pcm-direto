export interface StatusTagProps{status?:'ok'|'pendente'|'erro'|'ativo'|'inativo';children:React.ReactNode}
export declare function StatusTag(p:StatusTagProps):JSX.Element;