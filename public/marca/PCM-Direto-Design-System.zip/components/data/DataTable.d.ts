export interface DataTableProps{columns:string[];rows:React.ReactNode[][];caption?:string;/** column indexes rendered in IBM Plex Mono (IDs, TAGs, dates) */mono?:number[]}
/** @startingPoint section="Data" subtitle="Branded equipment table" viewport="700x300" */
export declare function DataTable(p:DataTableProps):JSX.Element;