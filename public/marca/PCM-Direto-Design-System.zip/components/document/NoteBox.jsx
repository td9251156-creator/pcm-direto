import React from 'react';
export function NoteBox({label='NOTA',children}){
  return <div style={{display:'flex',gap:12,background:'var(--superficie)',borderTop:'2px solid var(--laranja-sinal)',padding:'10px 14px',fontFamily:'var(--font-sans)',fontSize:13,color:'var(--tinta)'}}>
    <b style={{color:'var(--laranja-texto)',letterSpacing:'.06em'}}>{label}</b><span>{children}</span></div>;
}