"NOTA" callout: short warning the reader must not miss.
```jsx
<NoteBox>Aviso curto que o leitor não pode deixar passar.</NoteBox>
```