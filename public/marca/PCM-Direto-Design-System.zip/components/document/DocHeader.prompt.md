Standard document/sheet header: code, title, revision block, orange signal bar beneath.
```jsx
<DocHeader code="PCMD-03" title="Plano de manutenção" rev="00" date="25/10/2026" author="Pessoa A" approver="Pessoa B"/>
```