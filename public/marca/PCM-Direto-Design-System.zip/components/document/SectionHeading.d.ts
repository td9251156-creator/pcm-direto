export interface SectionHeadingProps{number?:string;level?:1|2;children:React.ReactNode}
export declare function SectionHeading(p:SectionHeadingProps):JSX.Element;