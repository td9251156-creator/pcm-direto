import React from 'react';
export function DocHeader({code='PCMD-00',title,rev='00',date,author,approver,logo}){
  const m={font:'11px var(--font-mono)',color:'var(--cinza-texto)'};
  return <div style={{borderBottom:'4px solid var(--laranja-sinal)',paddingBottom:12,display:'flex',gap:24,alignItems:'flex-end',fontFamily:'var(--font-sans)'}}>
    {logo}
    <div style={{flex:1}}><div style={m}>{code}</div><div style={{fontSize:22,fontWeight:800,color:'var(--azul-pcm)',lineHeight:1.15}}>{title}</div></div>
    <div style={{...m,textAlign:'right',lineHeight:1.6}}>Rev. {rev} · {date}<br/>Elaborado: {author}<br/>Aprovado: {approver}</div>
  </div>;
}