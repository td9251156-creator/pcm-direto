export interface NoteBoxProps{label?:string;children:React.ReactNode}
export declare function NoteBox(p:NoteBoxProps):JSX.Element;