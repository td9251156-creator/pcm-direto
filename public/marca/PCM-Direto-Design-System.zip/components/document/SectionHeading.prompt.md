Numbered section title for procedures. Level 1 = uppercase azul; level 2 = "5.1  Subtítulo".
```jsx
<SectionHeading number="1">Objetivo</SectionHeading>
<SectionHeading number="5.1" level={2}>Subtítulo de etapa</SectionHeading>
```