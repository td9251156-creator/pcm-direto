import React from 'react';
export function SectionHeading({number,children,level=1}){
  const s=level===1?{fontSize:18,fontWeight:700,color:'var(--azul-pcm)',textTransform:'uppercase',borderBottom:'1px solid var(--linha)',paddingBottom:6,margin:'24px 0 10px'}:{fontSize:15,fontWeight:700,color:'var(--tinta)',margin:'16px 0 6px'};
  return <div style={{fontFamily:'var(--font-sans)',...s}}>{number&&<span>{number}{level===1?'.':''}&nbsp;&nbsp;</span>}{children}</div>;
}