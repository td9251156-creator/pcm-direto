import React from 'react';
const MAP={vertical:'vertical',horizontal:'horizontal',slogan:'horizontal-slogan',icon:'icone-app'};
export function Logo({variant='horizontal',tone='cor',height=40,base='',style}){
  const t=variant==='icon'?(tone==='negativo'?'_negativo':''):'_'+tone;
  return <img alt="PCM Direto" src={base+'assets/logo/PCM-Direto_'+MAP[variant]+t+'.svg'} style={{height,display:'block',...style}}/>;
}