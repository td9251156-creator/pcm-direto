Official PCM Direto logo lockup (renders the brand SVG files); use in headers, covers, footers.
```jsx
<Logo variant="horizontal" tone="cor" height={32} base="../../"/>
```
Never use the slogan with the vertical lockup. Min height: vertical 36px, horizontal 22px.